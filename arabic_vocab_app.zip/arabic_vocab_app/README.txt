Open index.html in a web browser.

Features:
- Search Arabic, English, transliteration, roots, examples, and notes
- Filter by type, topic, and learning status
- Add, edit, delete, and update words
- Flashcard quiz
- JSON backup/import
- CSV export for Excel or Quizlet

Important:
Your edits are stored in that browser on that device. Export JSON regularly as a backup.
