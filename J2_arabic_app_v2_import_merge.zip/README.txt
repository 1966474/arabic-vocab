ED'S JORDANIAN ARABIC LIBRARY — VERSION 2.0

Upload index.html to the ROOT of your GitHub repository and replace the old index.html.

Important:
- Keep the same GitHub Pages address.
- The app uses the same browser storage key as the old app, so the words currently stored on that device should remain.
- After the updated app appears, tap Import & Merge and choose recent-update.json.
- The merge will preserve existing words and add/update the recent vocabulary without wiping the list.

Included:
1. index.html — the updated app
2. recent-update.json — the 36 recent vocabulary entries
